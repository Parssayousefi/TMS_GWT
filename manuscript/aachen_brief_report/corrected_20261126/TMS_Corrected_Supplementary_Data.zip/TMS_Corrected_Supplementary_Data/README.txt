Corrected TMS analyses, 26 November 2026.
Aachen input: reruns/aachen_skullstrip_skip_20261125/pipeline/results. SUDMEX original valid inputs retained.
Aachen participant estimates replace all historical Aachen effects.
Raw information nats; normalized information CDF units unless explicitly percentile points; counts and participation coefficients keep their native units.
Main clinical/imaging cohorts must not be pooled. All-post SUDMEX is a longitudinal sensitivity with later open-label visits.
Family-wise correction columns name their test family.
